# -*- coding: utf-8 -*-
"""Region geometry for the body plates.

viewBox 0 0 260 440, midline x = 130. Every band is defined generously wider
than the silhouette — the clipPath trims it — and bands are contiguous in y so
the painted regions tile the body with no white slivers.

GEO[region_id] = [(view, x, y, w, h, mirror), ...]
"""

def _r(x, y, x2, y2, mirror=False):
    return (x, y, x2 - x, y2 - y, mirror)


GEO = {
    # ---------------- head ----------------
    "vertex":       [("ant", *_r(52, 0, 208, 42)),   ("post", *_r(52, 0, 208, 42))],
    "temporal":     [("ant", *_r(52, 42, 106, 64, True)),
                     ("post", *_r(52, 42, 100, 76, True))],
    "frontal":      [("ant", *_r(106, 42, 154, 70))],
    "ear":          [("ant", *_r(52, 64, 106, 100, True))],
    "face":         [("ant", *_r(96, 70, 164, 100))],
    "occiput":      [("post", *_r(96, 42, 164, 76))],
    "suboccipital": [("post", *_r(96, 76, 164, 98))],

    # ---------------- neck ----------------
    "neck-ant":   [("ant", *_r(98, 96, 162, 126))],
    "neck-upper": [("post", *_r(98, 98, 162, 110))],
    "neck-mid":   [("post", *_r(98, 110, 162, 124))],
    "neck-lower": [("post", *_r(98, 124, 162, 146))],

    # ---------------- shoulder girdle ----------------
    "shoulder-top": [("ant",  *_r(40, 112, 101, 150, True)),
                     ("post", *_r(40, 112, 101, 148, True))],
    "scap-sup":     [("post", *_r(76, 146, 102, 172, True))],
    "interscap":    [("post", *_r(102, 146, 158, 214))],
    "scap-border":  [("post", *_r(76, 172, 102, 224, True))],
    "scap-inf":     [("post", *_r(60, 224, 102, 254, True))],

    # ---------------- trunk, anterior ----------------
    "chest-ant":  [("ant", *_r(100, 126, 160, 214))],
    "chest-lat":  [("ant", *_r(56, 150, 100, 214, True))],
    "epigastric": [("ant", *_r(56, 214, 204, 264))],
    "abd-lower":  [("ant", *_r(56, 264, 204, 322))],
    "groin":      [("ant", *_r(56, 322, 204, 380))],

    # ---------------- trunk, posterior ----------------
    "thoracic-mid":  [("post", *_r(102, 214, 158, 260))],
    "thoracolumbar": [("post", *_r(102, 260, 158, 308))],
    "flank":         [("post", *_r(56, 254, 102, 308, True))],
    "lumbar":        [("post", *_r(56, 308, 204, 354))],
    "si-buttock":    [("post", *_r(56, 354, 204, 400))],

    # ---------------- shoulder / arm ----------------
    "deltoid-lat":  [("ant", *_r(0, 130, 68, 194, True))],
    "deltoid-ant":  [("ant", *_r(68, 130, 112, 194, True))],
    "deltoid-post": [("post", *_r(0, 130, 112, 194, True))],
    "arm-ant":      [("ant", *_r(0, 194, 63, 254, True))],
    "arm-med":      [("ant", *_r(63, 194, 112, 254, True))],
    "arm-post":     [("post", *_r(0, 194, 112, 254, True))],

    # ---------------- elbow ----------------
    "elbow-lat":  [("ant",  *_r(0, 254, 53, 284, True)),
                   ("post", *_r(0, 254, 52, 284, True))],
    "elbow-ant":  [("ant", *_r(53, 254, 62, 284, True))],
    "elbow-med":  [("ant", *_r(62, 254, 112, 284, True))],
    "elbow-post": [("post", *_r(52, 254, 112, 284, True))],

    # ---------------- forearm ----------------
    "forearm-rad":   [("ant", *_r(0, 284, 47, 354, True))],
    "forearm-volar": [("ant", *_r(47, 284, 56, 354, True))],
    "forearm-uln":   [("ant", *_r(56, 284, 112, 354, True))],
    "forearm-dors":  [("post", *_r(0, 284, 112, 354, True))],

    # ---------------- wrist / hand ----------------
    "wrist":      [("ant",  *_r(0, 354, 112, 374, True)),
                   ("post", *_r(0, 354, 112, 374, True))],
    "thenar":     [("ant", *_r(0, 374, 38, 440, True))],
    "palm":       [("ant", *_r(38, 374, 112, 408, True))],
    "digits-rad": [("ant", *_r(38, 408, 54, 440, True))],
    "digits-uln": [("ant", *_r(54, 408, 112, 440, True))],
    "web-space":  [("post", *_r(0, 374, 36, 416, True))],
    "hand-dors":  [("post", *_r(36, 374, 112, 440, True)),
                   ("post", *_r(0, 416, 36, 440, True))],
}
