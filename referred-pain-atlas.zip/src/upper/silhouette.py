# -*- coding: utf-8 -*-
"""SVG silhouette paths for the anterior and posterior body plates.

viewBox 0 0 260 440, midline x = 130.
Drawn as three clip pieces (head+torso, two arms). The arms overlap the torso at
the acromion so the shoulder reads continuous, then angle outward so a clear gap
opens below the axilla. Region rects are painted through the union as a clipPath,
so the heat map takes the body outline for free.
"""

TORSO = (
    "M 130,10 "
    "C 152,10 170,30 170,52 "
    "C 170,75 157,93 146,97 "
    "L 146,113 "
    "C 162,117 176,125 184,140 "
    "L 178,158 "
    "L 174,182 "
    "L 170,240 "
    "L 168,286 "
    "L 173,330 "
    "C 173,352 168,366 160,372 "
    "L 100,372 "
    "C 92,366 87,352 87,330 "
    "L 92,286 "
    "L 90,240 "
    "L 86,182 "
    "L 82,158 "
    "L 76,140 "
    "C 84,125 98,117 114,113 "
    "L 114,97 "
    "C 103,93 90,75 90,52 "
    "C 90,30 108,10 130,10 Z"
)

# arm — patient's right (viewer-left). Overlaps the torso at the shoulder,
# then angles outward. Anterior version carries a thumb bump on the lateral side.
ARM_ANT = (
    "M 84,134 "
    "C 68,142 56,160 53,182 "
    "L 49,232 "
    "L 43,282 "
    "L 36,330 "
    "L 32,356 "
    "C 23,362 16,374 18,386 "
    "C 21,395 29,397 34,392 "
    "C 31,408 34,420 43,425 "
    "C 52,430 62,423 63,410 "
    "L 63,396 "
    "L 59,354 "
    "L 62,330 "
    "L 66,282 "
    "L 72,232 "
    "L 78,182 "
    "L 82,158 Z"
)

ARM_POST = (
    "M 84,134 "
    "C 68,142 56,160 53,182 "
    "L 49,232 "
    "L 43,282 "
    "L 36,330 "
    "L 32,356 "
    "C 22,362 15,376 17,392 "
    "C 20,412 36,424 50,420 "
    "C 60,416 64,404 63,392 "
    "L 59,354 "
    "L 62,330 "
    "L 66,282 "
    "L 72,232 "
    "L 78,182 "
    "L 82,158 Z"
)


def mirror_path(d: str) -> str:
    """Reflect an absolute-coordinate path about x = 130."""
    out, i, n = [], 0, len(d)
    while i < n:
        ch = d[i]
        if ch.isalpha() or ch in " ,":
            out.append(ch)
            i += 1
            continue
        j = i
        if d[j] in "+-":
            j += 1
        while j < n and (d[j].isdigit() or d[j] == "."):
            j += 1
        num = float(d[i:j])
        if j < n and d[j] == ",":     # x coordinates are followed by a comma
            num = 260.0 - num
        out.append("%g" % num)
        i = j
    return "".join(out)


SILHOUETTE = {
    "ant":  [TORSO, ARM_ANT,  mirror_path(ARM_ANT)],
    "post": [TORSO, ARM_POST, mirror_path(ARM_POST)],
}
